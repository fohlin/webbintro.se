function playGame(){
	// 1. Skapar våra frågor
	var questions = ["Vilken färg finns det mest av i den svenska flaggan?", "I vilket landskap ligger Malmö?", "I vilken film är Luke Skywalker huvudperson?"];
	// 2. Skapar våra svar
	var answers = ["Blå", "Skåne", "Star Wars"];
	// 3. Skapar variabeln points där vi håller reda på besökarens poäng
	var points = 0;
	
	// Ställer våra frågor
	for(i = 0; i < questions.length; i++){
		// Ställer frågan och sparar besökarens svar i variabeln "answer"
		var answer = prompt(questions[i]);
		
		//Kontrollerar om besökarens svar stämmer övernen med vårt svar
		if(answer == answers[i]){
			// Om det är rätt berättar vi det för användaren och ökar deras poäng med 1
			alert("Grattis, du svarade rätt!");
			points++;
		}else{
			// Om det är fel berättar vi det för användaren
			alert("Synd, du svarade fel");
		}
	}
	
	// Berättar den totalt poängen
	alert("Du fick " + points + " poäng");
}

function start(){
	// Lägger till "event handlers"
	document.getElementById("startGame").onclick = playGame;
}

window.onload = start;