// Fråga användaren efter namn & skriver ut en hälsning
 var name = prompt("Hej, vad heter du?");
 alert("Hej " + name + "!");
 console.log("Användaren heter: " + name);
 
 // Fråga användaren efter 2st tal, skriv ut resultatet
 var tal1 = prompt("Vänligen ange tal 1");
 var tal2 = prompt("Vänligen ange tal 2");
 var result = parseInt(tal1) + parseInt(tal2);
 document.write(tal1 + " + " + tal2 + " = " + result);