function showHide(){
	var article = this.nextSibling.nextSibling;
	if(article.style.display == "none"){
		article.style.display = "block";
	}else{
		article.style.display = "none";
	}

}

function start(){
	var h2 = document.getElementsByTagName("h2");
	for(var i = 0; i < h2.length; i++){
		h2[i].nextSibling.nextSibling.style.display = "none";
		h2[i].onclick = showHide;
	}
}

window.onload = start;