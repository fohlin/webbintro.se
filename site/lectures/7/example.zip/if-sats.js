var budget = prompt("Vilken är din bugdet?");
var spent = prompt("Hur mycket har du spenderat?");
var result = parseInt(budget) - parseInt(spent);

if(result > 0){
	alert("Grattis, du har festbudget kvar!");
}else if(result == 0){
	alert("Du lever på din budget, exakt!");
}else{
	alert("Tyvärr, knäckebröd och vatten som gäller!");
}