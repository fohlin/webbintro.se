for(var i = 0; i < 100; i++){
	// Kod här körs 10 gånger
	document.writeln("Kod i loopen<br>");
}


while(prompt("Vilket är Sveriges bästa fotbollslag?") != "Elfsborg"){
	alert("Du svarade fel, försök igen!");
}