function krToDollar(){
	var kr = prompt("Hur många kr vill du konvertera till dollar?");
	var result = parseInt(kr)/7.48;
	alert(kr + " blir $" +result);
}

function largeText(){
	document.body.style.fontSize = "50px";
}

function hideText(){
	document.getElementById("text").style.display = "none";
}
function showText(){
	document.getElementById("text").style.display = "block";
}

window.onload = start;

function start(){
	var button = document.getElementById("myButton");
	button.onclick = krToDollar;
	
	var largeTextButton = document.getElementById("largeText");
	largeTextButton.onclick = largeText;
	
	var hideButton = document.getElementById("hideText");
	hideButton.onclick = hideText;
	
	var showButton = document.getElementById("showText");
	showButton.onclick = showText;
}