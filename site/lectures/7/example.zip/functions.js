function welcome(){
	alert("Hej och välkommen till min sida!");
	var name = prompt("Vad heter du?");
	alert(name + " hoppas du gillar sidan!");
}

function showError(text){
	alert("Något blev fel, felmeddelande: " + text);
}

showError("Fel inloggning");
showError("Kunde inte hämta data från databasen");